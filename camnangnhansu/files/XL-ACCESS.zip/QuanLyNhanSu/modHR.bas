Option Compare Database
Option Explicit

#If VBA7 Then
Private Declare PtrSafe Function MessageBoxW Lib "user32" (ByVal hWnd As LongPtr, ByVal lpText As LongPtr, ByVal lpCaption As LongPtr, ByVal uType As Long) As Long
#Else
Private Declare Function MessageBoxW Lib "user32" (ByVal hWnd As Long, ByVal lpText As Long, ByVal lpCaption As Long, ByVal uType As Long) As Long
#End If

' ---- hang so (chuoi tieng Viet duoc chuyen sang ChrW khi sinh file) ----
Private Function TT_NGHI() As String
    TT_NGHI = (ChrW(272) & ChrW(227) & " ngh" & ChrW(7881) & " vi" & ChrW(7879) & "c")
End Function
Private Function TT_KHOAN() As String
    TT_KHOAN = ("C" & ChrW(7897) & "ng t" & ChrW(225) & "c (kho" & ChrW(225) & "n vi" & ChrW(7879) & "c)")
End Function
Private Function L_PL() As String
    L_PL = ("Ph" & ChrW(7909) & " l" & ChrW(7909) & "c H" & ChrW(272) & "L" & ChrW(272))
End Function
Private Function L_KXD() As String
    L_KXD = ("H" & ChrW(272) & "L" & ChrW(272) & " kh" & ChrW(244) & "ng x" & ChrW(225) & "c " & ChrW(273) & ChrW(7883) & "nh th" & ChrW(7901) & "i h" & ChrW(7841) & "n")
End Function
Private Function L_XD() As String
    L_XD = ("H" & ChrW(272) & "L" & ChrW(272) & " x" & ChrW(225) & "c " & ChrW(273) & ChrW(7883) & "nh th" & ChrW(7901) & "i h" & ChrW(7841) & "n")
End Function
Private Function L_DV() As String
    L_DV = ("H" & ChrW(7907) & "p " & ChrW(273) & ChrW(7891) & "ng d" & ChrW(7883) & "ch v" & ChrW(7909) & " (kho" & ChrW(225) & "n vi" & ChrW(7879) & "c)")
End Function
Private Function PHEP() As String
    PHEP = ("Ph" & ChrW(233) & "p n" & ChrW(259) & "m")
End Function
Private Function VN() As String
    VN = ("Vi" & ChrW(7879) & "t Nam")
End Function
Private Function NU() As String
    NU = ("N" & ChrW(7919))
End Function

Public Function Msg(ByVal s As String, Optional ByVal kieu As Long = 64) As Long
    Msg = MessageBoxW(Application.hWndAccessApp, StrPtr(s), StrPtr(Chuoi("tieu_de")), kieu)
End Function

Public Function Chuoi(ByVal khoa As String) As String
    Chuoi = Nz(DLookup("NoiDung", "tblMau", "Nhom='MSG' AND Kieu='" & khoa & "'"), khoa)
End Function

Public Function MoForm(ByVal ten As String)
    DoCmd.OpenForm ten
End Function

Public Function MoQuery(ByVal ten As String)
    DoCmd.OpenQuery ten, acViewNormal, acReadOnly
End Function

Public Function DongForm()
    On Error Resume Next
    DoCmd.Close acForm, Screen.ActiveForm.Name
End Function

Public Function XuatExcel(ByVal ten As String)
    Dim p As String
    On Error GoTo Loi
    p = CurrentProject.Path & "\" & ten & "_" & Format(Now, "yyyymmdd_hhnnss") & ".xlsx"
    DoCmd.TransferSpreadsheet acExport, 10, ten, p, True
    Application.FollowHyperlink p
    Exit Function
Loi:
    Msg Chuoi("loi") & vbCrLf & Err.Description, 48
End Function

Public Function TS(ByVal truong As String) As Variant
    TS = Nz(DLookup(truong, "tblThamSo", "ID=1"), 0)
End Function

Private Function Mx(ByVal a As Double, ByVal b As Double) As Double
    If a > b Then Mx = a Else Mx = b
End Function

Private Function Mn(ByVal a As Double, ByVal b As Double) As Double
    If a < b Then Mn = a Else Mn = b
End Function

Private Function SqlNgay(ByVal d As Date) As String
    SqlNgay = "#" & Format(d, "mm\/dd\/yyyy") & "#"
End Function

Private Function Q(ByVal s As Variant) As String
    Q = "'" & Replace(Nz(s, ""), "'", "''") & "'"
End Function

Public Function SoNPT(ByVal ma As Variant, ByVal d1 As Date, ByVal d2 As Date) As Long
    SoNPT = DCount("*", "tblNguoiPhuThuoc", "MaNV=" & Q(ma) & " AND TuNgay<=" & SqlNgay(d2) & " AND (DenNgay Is Null OR DenNgay>=" & SqlNgay(d1) & ")")
End Function

Public Function ThueTNCN(ByVal tn As Double) As Double
    If tn <= 0 Then
        ThueTNCN = 0
    ElseIf tn <= 10000000 Then
        ThueTNCN = tn * 0.05
    ElseIf tn <= 30000000 Then
        ThueTNCN = tn * 0.1 - 500000
    ElseIf tn <= 60000000 Then
        ThueTNCN = tn * 0.2 - 3500000
    ElseIf tn <= 100000000 Then
        ThueTNCN = tn * 0.3 - 9500000
    Else
        ThueTNCN = tn * 0.35 - 14500000
    End If
    ThueTNCN = Round(ThueTNCN, 0)
End Function

Public Function PhepDuocHuong(ByVal ma As Variant, ByVal nam As Variant) As Double
    Dim vl As Variant, nv As Variant, cb As Double, tn As Long, st As Date, en As Date, thang As Long
    vl = DLookup("NgayVaoLam", "tblNhanVien", "MaNV=" & Q(ma))
    If IsNull(vl) Then Exit Function
    nv = DLookup("NgayNghiViec", "tblNhanVien", "MaNV=" & Q(ma))
    cb = Nz(DLookup("PhepCoBan", "tblNhanVien", "MaNV=" & Q(ma)), 0)
    If cb = 0 Then cb = TS("PhepCoBan")
    tn = DateDiff("yyyy", vl, DateSerial(nam, 12, 31))
    If DateSerial(Year(vl) + tn, Month(vl), Day(vl)) > DateSerial(nam, 12, 31) Then tn = tn - 1
    If tn < 0 Then tn = 0
    st = vl
    If st < DateSerial(nam, 1, 1) Then st = DateSerial(nam, 1, 1)
    en = DateSerial(nam, 12, 31)
    If Not IsNull(nv) Then
        If nv < en Then en = nv
    End If
    If en < st Then Exit Function
    thang = (Year(en) - Year(st)) * 12 + Month(en) - Month(st) + 1
    If thang >= 12 Then
        PhepDuocHuong = cb + tn \ 5
    Else
        PhepDuocHuong = Round((cb + tn \ 5) * thang / 12, 0)
    End If
End Function

Public Function PhepDaNghi(ByVal ma As Variant, ByVal nam As Variant) As Double
    PhepDaNghi = Nz(DSum("SoNgay", "tblNghi", "MaNV=" & Q(ma) & " AND LoaiNghi=" & Q(PHEP()) & " AND Year(TuNgay)=" & nam), 0)
End Function

Public Function TinhLuong(ByVal nam As Variant, ByVal thang As Variant)
    Dim db As DAO.Database, rs As DAO.Recordset, ro As DAO.Recordset
    Dim d1 As Date, d2 As Date, cc As Double, lttv As Double, tc As Double, tranXH As Double, tranTN As Double
    Dim w As String, cong As Double, ltT As Double, ltN As Double, ltL As Double, dem As Double, thuong As Double, tamung As Double
    Dim luongCB As Double, luongCong As Double, lgio As Double, tienLT As Double, mienLT As Double, pcKBH As Double, tong As Double
    Dim luongBH As Double, bhxh As Double, bhyt As Double, bhtn As Double, doanphi As Double, npt As Long, giamtru As Double
    Dim khongThue As Double, tntt As Double, thue As Double, nuocNgoai As Boolean, coBH As Boolean, n As Long
    nam = Nz(nam, 0): thang = Nz(thang, 0)
    If nam < 2000 Or thang < 1 Or thang > 12 Then
        Msg Chuoi("ky_sai"), 48
        Exit Function
    End If
    Set db = CurrentDb
    d1 = DateSerial(nam, thang, 1): d2 = DateSerial(nam, thang + 1, 0)
    cc = TS("CongChuan"): If cc <= 0 Then cc = 26
    lttv = TS("LTTV"): tc = TS("MucThamChieu")
    tranXH = 20 * tc: tranTN = 20 * lttv
    db.Execute "DELETE FROM tblBangLuong WHERE Nam=" & nam & " AND Thang=" & thang, dbFailOnError
    Set rs = db.OpenRecordset("SELECT n.*, b.TenBP FROM tblNhanVien AS n LEFT JOIN tblBoPhan AS b ON n.MaBP=b.MaBP WHERE n.TrangThai<>" & Q(TT_NGHI()) & " AND n.TrangThai<>" & Q(TT_KHOAN()) & " ORDER BY n.MaNV", dbOpenSnapshot)
    Set ro = db.OpenRecordset("tblBangLuong", dbOpenDynaset)
    Do While Not rs.EOF
        w = "MaNV=" & Q(rs!MaNV) & " AND Nam=" & nam & " AND Thang=" & thang
        cong = Nz(DLookup("CongHuongLuong", "tblChamCong", w), cc)
        ltT = Nz(DLookup("GioLTThuong", "tblChamCong", w), 0)
        ltN = Nz(DLookup("GioLTNghi", "tblChamCong", w), 0)
        ltL = Nz(DLookup("GioLTLe", "tblChamCong", w), 0)
        dem = Nz(DLookup("GioDem", "tblChamCong", w), 0)
        thuong = Nz(DLookup("Thuong", "tblChamCong", w), 0)
        tamung = Nz(DLookup("TamUng", "tblChamCong", w), 0)
        luongCB = Nz(rs!MucLuong, 0) + Nz(rs!PhuCapLuong, 0) + Nz(rs!KhoanBoSung, 0)
        luongCong = Round(luongCB / cc * cong, 0)
        lgio = luongCB / cc / 8
        tienLT = Round(lgio * (1.5 * ltT + 2 * ltN + 3 * ltL + 0.3 * dem), 0)
        mienLT = Round(lgio * (0.5 * ltT + 1 * ltN + 2 * ltL + 0.3 * dem), 0)
        pcKBH = Round(Nz(rs!PhuCapKhongBH, 0) * cong / cc, 0)
        tong = luongCong + tienLT + pcKBH + thuong
        coBH = Nz(rs!ThamGiaBHXH, False)
        nuocNgoai = (Nz(rs!QuocTich, "") <> VN())
        If coBH Then luongBH = Mx(lttv, Mn(luongCB, tranXH)) Else luongBH = 0
        bhxh = Round(luongBH * 0.08, 0): bhyt = Round(luongBH * 0.015, 0)
        If coBH And Not nuocNgoai Then bhtn = Round(Mx(lttv, Mn(luongCB, tranTN)) * 0.01, 0) Else bhtn = 0
        If Nz(rs!DoanVien, False) Then doanphi = Round(Mn(luongBH * 0.01, 0.1 * tc), 0) Else doanphi = 0
        npt = SoNPT(rs!MaNV, d1, d2)
        giamtru = TS("GiamTruBanThan") + npt * TS("GiamTruNPT")
        khongThue = mienLT + Mn(pcKBH, Nz(rs!KhongChiuThue, 0))
        tntt = Mx(0, tong - khongThue - bhxh - bhyt - bhtn - giamtru)
        thue = ThueTNCN(tntt)
        ro.AddNew
        ro!Nam = nam: ro!Thang = thang: ro!MaNV = rs!MaNV: ro!HoTen = rs!HoTen: ro!BoPhan = rs!TenBP
        ro!CongHuongLuong = cong: ro!LuongTheoCong = luongCong: ro!TienLamThem = tienLT: ro!PhuCapKhongBH = pcKBH: ro!Thuong = thuong
        ro!TongThuNhap = tong: ro!LuongDongBH = luongBH: ro!BHXH = bhxh: ro!BHYT = bhyt: ro!BHTN = bhtn: ro!DoanPhi = doanphi
        ro!SoNPT = npt: ro!GiamTru = giamtru: ro!KhongChiuThue = khongThue: ro!TNTinhThue = tntt: ro!ThueTNCN = thue: ro!TamUng = tamung
        ro!ThucLinh = tong - bhxh - bhyt - bhtn - doanphi - thue - tamung
        ro!DNDongBH = Round(luongBH * 0.205, 0) + bhtn
        ro!KPCD = Round(luongBH * 0.02, 0)
        ro!ChiPhiDN = tong + ro!DNDongBH + ro!KPCD
        ro.Update
        n = n + 1
        rs.MoveNext
    Loop
    rs.Close: ro.Close
    DoCmd.OpenForm "frmBangLuong", acFormDS, , "Nam=" & nam & " AND Thang=" & thang
    Msg Chuoi("luong_xong") & " " & thang & "/" & nam & ": " & n
End Function

Private Function NgayTxt(ByVal d As Variant) As String
    If IsNull(d) Or IsEmpty(d) Then
        NgayTxt = ".../.../......"
    Else
        NgayTxt = Format(d, "dd\/mm\/yyyy")
    End If
End Function

Private Function SoTxt(ByVal x As Variant) As String
    SoTxt = Format(Nz(x, 0), "#,##0")
End Function

Private Function ThayThe(ByVal s As String, nv As DAO.Recordset, hd As DAO.Recordset, tso As DAO.Recordset) As String
    s = Replace(s, "{TenDN}", Nz(tso!TenDN, "")): s = Replace(s, "{DiaChiDN}", Nz(tso!DiaChi, "")): s = Replace(s, "{MSTDN}", Nz(tso!MST, ""))
    s = Replace(s, "{DienThoaiDN}", Nz(tso!DienThoai, "")): s = Replace(s, "{NguoiDD}", Nz(tso!NguoiDaiDien, "")): s = Replace(s, "{ChucVuDD}", Nz(tso!ChucVu, ""))
    s = Replace(s, "{NoiKy}", Nz(tso!NoiKy, "")): s = Replace(s, "{NgayTra}", Nz(tso!NgayTraLuong, "")): s = Replace(s, "{NghiTuan}", Nz(tso!NghiTuan, ""))
    s = Replace(s, "{SoHD}", Nz(hd!SoHD, "")): s = Replace(s, "{NgayKy}", NgayTxt(hd!NgayKy)): s = Replace(s, "{TuNgay}", NgayTxt(hd!TuNgay)): s = Replace(s, "{DenNgay}", NgayTxt(hd!DenNgay))
    If IsNull(hd!DenNgay) Or IsNull(hd!TuNgay) Then
        s = Replace(s, "{ThoiHan}", "...")
    Else
        s = Replace(s, "{ThoiHan}", CStr(DateDiff("m", hd!TuNgay, hd!DenNgay + 1)))
    End If
    s = Replace(s, "{ChucDanh}", Nz(hd!ChucDanh, Nz(nv!ChucDanh, ""))): s = Replace(s, "{MucLuong}", SoTxt(hd!MucLuong)): s = Replace(s, "{PhuCap}", SoTxt(hd!PhuCap))
    s = Replace(s, "{BoSung}", SoTxt(nv!KhoanBoSung)): s = Replace(s, "{PCKhongBH}", SoTxt(nv!PhuCapKhongBH))
    If Nz(nv!GioiTinh, "") = NU() Then s = Replace(s, "{OngBa}", Chuoi("ba")) Else s = Replace(s, "{OngBa}", Chuoi("ong"))
    s = Replace(s, "{HoTen}", Nz(nv!HoTen, "")): s = Replace(s, "{NgaySinh}", NgayTxt(nv!NgaySinh)): s = Replace(s, "{GioiTinh}", Nz(nv!GioiTinh, ""))
    s = Replace(s, "{QuocTich}", Nz(nv!QuocTich, "")): s = Replace(s, "{SoDinhDanh}", Nz(nv!SoDinhDanh, "") & Nz(nv!HoChieu, "")): s = Replace(s, "{NgayCap}", NgayTxt(nv!NgayCap))
    s = Replace(s, "{NoiCap}", Nz(nv!NoiCap, "")): s = Replace(s, "{ThuongTru}", Nz(nv!DiaChiThuongTru, "")): s = Replace(s, "{NoiO}", Nz(nv!NoiOHienTai, ""))
    s = Replace(s, "{DienThoai}", Nz(nv!DienThoai, "")): s = Replace(s, "{TrinhDo}", Nz(nv!TrinhDo, "")): s = Replace(s, "{NoiLamViec}", Nz(nv!NoiLamViec, ""))
    s = Replace(s, "{SoTK}", Nz(nv!SoTaiKhoan, "")): s = Replace(s, "{NganHang}", Nz(nv!NganHang, ""))
    ThayThe = s
End Function

Private Sub ThemDoan(doc As Object, ByVal s As String, ByVal kieu As String)
    Dim rg As Object
    Set rg = doc.Paragraphs(doc.Paragraphs.Count).Range
    rg.InsertBefore s
    Set rg = doc.Paragraphs(doc.Paragraphs.Count).Range
    rg.Font.Name = "Times New Roman"
    rg.Font.Size = 13
    rg.Font.Bold = (kieu = "tieude" Or kieu = "dieu" Or kieu = "quochieu" Or kieu = "ben")
    If kieu = "tieude" Then rg.Font.Size = 15
    If kieu = "tieude" Or kieu = "giua" Or kieu = "quochieu" Then
        rg.ParagraphFormat.Alignment = 1
    Else
        rg.ParagraphFormat.Alignment = 3
    End If
    rg.ParagraphFormat.SpaceAfter = 4
    rg.ParagraphFormat.KeepWithNext = (kieu = "dieu" Or kieu = "cuoi")
    doc.Content.InsertParagraphAfter
End Sub

Private Sub ChenKy(doc As Object, ByVal s As String)
    Dim a() As String, rg As Object, t As Object
    a = Split(s, "|")
    If UBound(a) < 3 Then Exit Sub
    Set rg = doc.Paragraphs(doc.Paragraphs.Count).Range
    Set t = doc.Tables.Add(rg, 2, 2)
    t.Borders.Enable = False
    t.Cell(1, 1).Range.Text = Replace(a(0), "~", vbCr)
    t.Cell(1, 2).Range.Text = Replace(a(1), "~", vbCr)
    t.Cell(2, 1).Range.Text = vbCr & vbCr & vbCr & a(2)
    t.Cell(2, 2).Range.Text = vbCr & vbCr & vbCr & a(3)
    t.Range.Font.Name = "Times New Roman"
    t.Range.Font.Size = 13
    t.Range.Font.Bold = True
    t.Range.ParagraphFormat.Alignment = 1
    t.Range.ParagraphFormat.KeepWithNext = True
    t.Rows.AllowBreakAcrossPages = False
End Sub

Public Function InHopDong(ByVal ma As Variant)
    Dim db As DAO.Database, nv As DAO.Recordset, hd As DAO.Recordset, tso As DAO.Recordset, mau As DAO.Recordset
    Dim nhom As String, wd As Object, doc As Object, s As String, kieu As String
    On Error GoTo Loi
    If IsNull(ma) Then Exit Function
    If Len(ma & "") = 0 Then Exit Function
    Set db = CurrentDb
    Set nv = db.OpenRecordset("SELECT * FROM tblNhanVien WHERE MaNV=" & Q(ma), dbOpenSnapshot)
    If nv.EOF Then Exit Function
    Set hd = db.OpenRecordset("SELECT TOP 1 * FROM tblHopDong WHERE MaNV=" & Q(ma) & " AND LoaiHD<>" & Q(L_PL()) & " ORDER BY TuNgay DESC, ID DESC", dbOpenSnapshot)
    If hd.EOF Then
        Msg Chuoi("chua_co_hd"), 48
        Exit Function
    End If
    nhom = ""
    If hd!LoaiHD = L_KXD() Then nhom = "KXD"
    If hd!LoaiHD = L_XD() Then nhom = "XD"
    If hd!LoaiHD = L_DV() Then nhom = "DV"
    If nhom = "" Then
        Msg Chuoi("khong_co_mau"), 48
        Exit Function
    End If
    Set tso = db.OpenRecordset("SELECT * FROM tblThamSo WHERE ID=1", dbOpenSnapshot)
    Set mau = db.OpenRecordset("SELECT * FROM tblMau WHERE Nhom='" & nhom & "' ORDER BY ThuTu", dbOpenSnapshot)
    Set wd = CreateObject("Word.Application")
    Set doc = wd.Documents.Add
    doc.PageSetup.TopMargin = 57: doc.PageSetup.BottomMargin = 57
    doc.PageSetup.LeftMargin = 85: doc.PageSetup.RightMargin = 57
    Do While Not mau.EOF
        s = ThayThe(Nz(mau!NoiDung, ""), nv, hd, tso)
        kieu = Nz(mau!Kieu, "doan")
        If kieu = "ky" Then
            ChenKy doc, s
        Else
            ThemDoan doc, s, kieu
        End If
        mau.MoveNext
    Loop
    wd.Visible = True
    wd.Activate
    Exit Function
Loi:
    Msg Chuoi("loi") & vbCrLf & Err.Description, 48
End Function
